<div id="wrapper">
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">FCI BILLING SYSTEM</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul id="active" class="nav navbar-nav side-nav">
                    <li><a href="subs_list.php"><i class="fa fa-users"></i> Subscribers </a></li>
                
                    <li><a href="setup.php"><i class="fa fa-edit"></i> Set Up </a></li>

                    <li><a href="reports.php"><i class="fa fa-folder"></i> Reports </a></li>
                    
                    <li><a href="admin_list.php"><i class="fa fa-user"></i> Admin </a></li>
                    
                    <li><a href="include/logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
                
            </div>
        </nav>
