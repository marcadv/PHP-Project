<?php

$condb = mysqli_connect('localhost', 'root');

mysqli_select_db($condb, 'fcibs');


?>